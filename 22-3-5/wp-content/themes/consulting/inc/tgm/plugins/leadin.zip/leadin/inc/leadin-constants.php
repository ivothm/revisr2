<?php

if ( ! defined( 'LEADIN_UTM_SOURCE' ) ) {
	define( 'LEADIN_UTM_SOURCE', 'leadin%20repo%20plugin' );
}

if ( ! defined( 'LEADIN_UTM_MEDIUM' ) ) {
	define( 'LEADIN_UTM_MEDIUM', 'referral' );
}

if ( ! defined( 'LEADIN_UTM_CONTENT' ) ) {
	define( 'LEADIN_UTM_CONTENT', 'e10' );
}

if ( ! defined( 'LEADIN_UTM_CAMPAIGN' ) ) {
	define( 'LEADIN_UTM_CAMPAIGN', 'one%20click%20updater' );
}


